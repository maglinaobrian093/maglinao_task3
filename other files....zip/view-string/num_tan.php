<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include("../db.php");

$sql = "SELECT ROUND(amount/1000,4) AS x, TAN(ROUND(amount/1000,4)) AS result FROM orders;";
$result = $conn->query($sql);
if (!$result) {
  die("Query error: " . $conn->error . "<br><pre>$sql</pre>");
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>TAN() Output</title>
  <style>
    body { font-family: Arial, sans-serif; padding: 20px; }
    table { border-collapse: collapse; width: 100%; margin-top: 10px; }
    th, td { border: 1px solid #ccc; padding: 8px; }
    th { background: #f4f4f4; }
    pre { background: #fafafa; border: 1px solid #ddd; padding: 10px; }
  </style>
</head>
<body>
  <h2>TAN()</h2>
  <p><b>SQL:</b></p>
  <pre>SELECT ROUND(amount/1000,4) AS x, TAN(ROUND(amount/1000,4)) AS result FROM orders;</pre>

  <?php if ($result instanceof mysqli_result): ?>
    <?php if ($result->num_rows > 0): ?>
      <table>
        <tr>
          <?php foreach ($result->fetch_fields() as $f): ?>
            <th><?= htmlspecialchars($f->name) ?></th>
          <?php endforeach; ?>
        </tr>
        <?php $result->data_seek(0); ?>
        <?php while($row = $result->fetch_assoc()): ?>
          <tr>
            <?php foreach ($row as $val): ?>
              <td><?= htmlspecialchars((string)$val) ?></td>
            <?php endforeach; ?>
          </tr>
        <?php endwhile; ?>
      </table>
    <?php else: ?>
      <p>No rows returned.</p>
    <?php endif; ?>
  <?php else: ?>
    <p>Query executed.</p>
  <?php endif; ?>

  <p><a href="../index.php">← Back to index</a></p>
</body>
</html>