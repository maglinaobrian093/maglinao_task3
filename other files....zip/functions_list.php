<?php


$string_functions = [

["str_ascii","ASCII()","Returns ASCII code of first character",
"SELECT full_name, ASCII(full_name) AS result FROM employees;"],

["str_char_length","CHAR_LENGTH()","Length of string in characters",
"SELECT full_name, CHAR_LENGTH(full_name) AS result FROM employees;"],

["str_character_length","CHARACTER_LENGTH()","Same as CHAR_LENGTH",
"SELECT full_name, CHARACTER_LENGTH(full_name) AS result FROM employees;"],

["str_concat","CONCAT()","Concatenates strings",
"SELECT CONCAT(full_name,' - ',department) AS result FROM employees;"],

["str_concat_ws","CONCAT_WS()","Concatenates with separator",
"SELECT CONCAT_WS(' | ', full_name, department, email) AS result FROM employees;"],

["str_field","FIELD()","Returns index position in list",
"SELECT department, FIELD(department,'HR','IT','Finance','Sales') AS result FROM employees;"],

["str_find_in_set","FIND_IN_SET()","Find string in comma-separated list",
"SELECT department, FIND_IN_SET(department,'HR,IT,Finance,Sales') AS result FROM employees;"],

["str_insert","INSERT()","Insert substring at position",
"SELECT full_name, INSERT(full_name,1,3,'***') AS result FROM employees;"],

["str_instr","INSTR()","Position of substring",
"SELECT email, INSTR(email,'@') AS result FROM employees;"],

["str_lcase","LCASE()","Lowercase string",
"SELECT full_name, LCASE(full_name) AS result FROM employees;"],

["str_left","LEFT()","Left n characters",
"SELECT full_name, LEFT(full_name,4) AS result FROM employees;"],

["str_length","LENGTH()","Length in bytes",
"SELECT full_name, LENGTH(full_name) AS result FROM employees;"],

["str_locate","LOCATE()","Locate substring",
"SELECT email, LOCATE('@',email) AS result FROM employees;"],

["str_lower","LOWER()","Lowercase string",
"SELECT full_name, LOWER(full_name) AS result FROM employees;"],

["str_lpad","LPAD()","Pad left",
"SELECT department, LPAD(department,10,'*') AS result FROM employees;"],

["str_ltrim","LTRIM()","Remove leading spaces",
"SELECT LTRIM('   hello') AS result;"],

["str_mid","MID()","Extract substring",
"SELECT email, MID(email,1,4) AS result FROM employees;"],

["str_position","POSITION()","Position of substring",
"SELECT email, POSITION('@' IN email) AS result FROM employees;"],

["str_repeat","REPEAT()","Repeat string",
"SELECT REPEAT('*',10) AS result;"],

["str_replace","REPLACE()","Replace substring",
"SELECT email, REPLACE(email,'@mail.com','@gmail.com') AS result FROM employees;"],

["str_reverse","REVERSE()","Reverse string",
"SELECT full_name, REVERSE(full_name) AS result FROM employees;"],

["str_right","RIGHT()","Right n characters",
"SELECT email, RIGHT(email,9) AS result FROM employees;"],

["str_rpad","RPAD()","Pad right",
"SELECT department, RPAD(department,10,'.') AS result FROM employees;"],

["str_rtrim","RTRIM()","Remove trailing spaces",
"SELECT RTRIM('hello   ') AS result;"],

["str_space","SPACE()","Return spaces",
"SELECT CONCAT('A',SPACE(5),'B') AS result;"],

["str_strcmp","STRCMP()","Compare strings",
"SELECT STRCMP('abc','abd') AS result;"],

["str_substr","SUBSTR()","Substring",
"SELECT email, SUBSTR(email,1,4) AS result FROM employees;"],

["str_substring","SUBSTRING()","Substring",
"SELECT email, SUBSTRING(email,1,4) AS result FROM employees;"],

["str_substring_index","SUBSTRING_INDEX()","Substring before delimiter",
"SELECT email, SUBSTRING_INDEX(email,'@',1) AS result FROM employees;"],

["str_trim","TRIM()","Trim spaces",
"SELECT TRIM('   hello   ') AS result;"],

["str_ucase","UCASE()","Uppercase string",
"SELECT full_name, UCASE(full_name) AS result FROM employees;"],

["str_upper","UPPER()","Uppercase string",
"SELECT full_name, UPPER(full_name) AS result FROM employees;"]

];



$numeric_functions = [

["num_abs","ABS()","Absolute value",
"SELECT amount, ABS(amount-1000) AS result FROM orders;"],

["num_ceil","CEIL()","Ceiling value",
"SELECT amount, CEIL(amount) AS result FROM orders;"],

["num_ceiling","CEILING()","Ceiling value",
"SELECT amount, CEILING(amount) AS result FROM orders;"],

["num_div","DIV","Integer division",
"SELECT amount, amount DIV 3 AS result FROM orders;"],

["num_floor","FLOOR()","Floor value",
"SELECT amount, FLOOR(amount) AS result FROM orders;"],

["num_round","ROUND()","Round value",
"SELECT amount, ROUND(amount,0) AS result FROM orders;"],

["num_truncate","TRUNCATE()","Truncate decimals",
"SELECT amount, TRUNCATE(amount,1) AS result FROM orders;"],

["num_mod","MOD()","Remainder",
"SELECT amount, MOD(amount,7) AS result FROM orders;"],

["num_sign","SIGN()","Sign of number",
"SELECT amount-1000 AS x, SIGN(amount-1000) AS result FROM orders;"],

["num_sqrt","SQRT()","Square root",
"SELECT amount, SQRT(amount) AS result FROM orders;"],

["num_pow","POW()","Power",
"SELECT POW(2,3) AS result;"],

["num_power","POWER()","Power",
"SELECT POWER(3,4) AS result;"],

["num_exp","EXP()","Exponential",
"SELECT EXP(1) AS result;"],

["num_ln","LN()","Natural log",
"SELECT LN(amount) AS result FROM orders;"],

["num_log","LOG()","Logarithm",
"SELECT LOG(amount) AS result FROM orders;"],

["num_log10","LOG10()","Base-10 log",
"SELECT LOG10(amount) AS result FROM orders;"],

["num_log2","LOG2()","Base-2 log",
"SELECT LOG2(amount) AS result FROM orders;"],

["num_pi","PI()","Pi constant",
"SELECT PI() AS result;"],

["num_rand","RAND()","Random number",
"SELECT RAND() AS result;"],

["num_radians","RADIANS()","Degrees to radians",
"SELECT RADIANS(90) AS result;"],

["num_degrees","DEGREES()","Radians to degrees",
"SELECT DEGREES(1.57) AS result;"],

["num_sin","SIN()","Sine",
"SELECT SIN(1) AS result;"],

["num_cos","COS()","Cosine",
"SELECT COS(1) AS result;"],

["num_tan","TAN()","Tangent",
"SELECT TAN(1) AS result;"],

["num_cot","COT()","Cotangent",
"SELECT COT(1) AS result;"],

["num_asin","ASIN()","Arc sine",
"SELECT ASIN(0.5) AS result;"],

["num_acos","ACOS()","Arc cosine",
"SELECT ACOS(0.5) AS result;"],

["num_atan","ATAN()","Arc tangent",
"SELECT ATAN(1) AS result;"],

["num_atan2","ATAN2()","Arc tangent of y/x",
"SELECT ATAN2(5,3) AS result;"],

["num_least","LEAST()","Smallest value",
"SELECT LEAST(10,20,5) AS result;"],

["num_greatest","GREATEST()","Largest value",
"SELECT GREATEST(10,20,5) AS result;"],

["num_format","FORMAT()","Format number",
"SELECT FORMAT(amount,2) AS result FROM orders;"],

["num_cosh","COSH()","Hyperbolic cosine",
"SELECT COSH(1) AS result;"],

["num_sinh","SINH()","Hyperbolic sine",
"SELECT SINH(1) AS result;"],

["num_tanh","TANH()","Hyperbolic tangent",
"SELECT TANH(1) AS result;"]

];

$date_functions = [

["date_now","NOW()","Current date & time",
"SELECT NOW() AS result;"],

["date_curdate","CURDATE()","Current date",
"SELECT CURDATE() AS result;"],

["date_curtime","CURTIME()","Current time",
"SELECT CURTIME() AS result;"],

["date_current_date","CURRENT_DATE","Current date (synonym)",
"SELECT CURRENT_DATE AS result;"],

["date_current_time","CURRENT_TIME","Current time (synonym)",
"SELECT CURRENT_TIME AS result;"],

["date_current_timestamp","CURRENT_TIMESTAMP","Current timestamp (synonym)",
"SELECT CURRENT_TIMESTAMP AS result;"],

["date_date","DATE()","Extract date part from datetime",
"SELECT DATE(NOW()) AS result;"],

["date_time","TIME()","Extract time part from datetime",
"SELECT TIME(NOW()) AS result;"],

["date_year","YEAR()","Extract year",
"SELECT YEAR(NOW()) AS result;"],

["date_month","MONTH()","Extract month number",
"SELECT MONTH(NOW()) AS result;"],

["date_day","DAY()","Extract day of month",
"SELECT DAY(NOW()) AS result;"],

["date_dayname","DAYNAME()","Day name",
"SELECT DAYNAME(CURDATE()) AS result;"],

["date_monthname","MONTHNAME()","Month name",
"SELECT MONTHNAME(CURDATE()) AS result;"],

["date_dayofweek","DAYOFWEEK()","Day of week (1=Sun..7=Sat)",
"SELECT DAYOFWEEK(CURDATE()) AS result;"],

["date_weekday","WEEKDAY()","Weekday (0=Mon..6=Sun)",
"SELECT WEEKDAY(CURDATE()) AS result;"],

["date_dayofyear","DAYOFYEAR()","Day of year (1..366)",
"SELECT DAYOFYEAR(CURDATE()) AS result;"],

["date_week","WEEK()","Week number",
"SELECT WEEK(CURDATE()) AS result;"],

["date_weekofyear","WEEKOFYEAR()","Week number (1..53)",
"SELECT WEEKOFYEAR(CURDATE()) AS result;"],

["date_quarter","QUARTER()","Quarter (1..4)",
"SELECT QUARTER(CURDATE()) AS result;"],

["date_hour","HOUR()","Extract hour",
"SELECT HOUR(NOW()) AS result;"],

["date_minute","MINUTE()","Extract minute",
"SELECT MINUTE(NOW()) AS result;"],

["date_second","SECOND()","Extract second",
"SELECT SECOND(NOW()) AS result;"],

["date_date_format","DATE_FORMAT()","Format date/time",
"SELECT DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s') AS result;"],

["date_time_format","TIME_FORMAT()","Format time",
"SELECT TIME_FORMAT(CURTIME(), '%H:%i:%s') AS result;"],

["date_str_to_date","STR_TO_DATE()","Convert string to date",
"SELECT STR_TO_DATE('2026-02-07', '%Y-%m-%d') AS result;"],

["date_datediff","DATEDIFF()","Days between two dates",
"SELECT DATEDIFF('2026-12-31','2026-01-01') AS result;"],

["date_timediff","TIMEDIFF()","Time difference",
"SELECT TIMEDIFF('12:30:00','08:15:00') AS result;"],

["date_date_add","DATE_ADD()","Add interval to date",
"SELECT DATE_ADD('2026-02-07', INTERVAL 7 DAY) AS result;"],

["date_date_sub","DATE_SUB()","Subtract interval from date",
"SELECT DATE_SUB('2026-02-07', INTERVAL 7 DAY) AS result;"],

["date_adddate","ADDDATE()","Add interval to date (synonym)",
"SELECT ADDDATE('2026-02-07', INTERVAL 1 MONTH) AS result;"],

["date_subdate","SUBDATE()","Subtract interval from date (synonym)",
"SELECT SUBDATE('2026-02-07', INTERVAL 1 MONTH) AS result;"],

["date_last_day","LAST_DAY()","Last day of month",
"SELECT LAST_DAY('2026-02-07') AS result;"],

["date_makedate","MAKEDATE()","Create date from year + day-of-year",
"SELECT MAKEDATE(2026, 38) AS result;"],

["date_maketime","MAKETIME()","Create time from hour/min/sec",
"SELECT MAKETIME(14, 5, 9) AS result;"],

["date_unix_timestamp","UNIX_TIMESTAMP()","Unix timestamp (seconds)",
"SELECT UNIX_TIMESTAMP(NOW()) AS result;"],

["date_from_unixtime","FROM_UNIXTIME()","Convert unix timestamp to datetime",
"SELECT FROM_UNIXTIME(UNIX_TIMESTAMP(NOW())) AS result;"],

["date_extract","EXTRACT()","Extract part using EXTRACT()",
"SELECT EXTRACT(YEAR_MONTH FROM NOW()) AS result;"],

["date_timestamp","TIMESTAMP()","Build timestamp from date + time",
"SELECT TIMESTAMP('2026-02-07','13:45:00') AS result;"],

["date_timestampdiff","TIMESTAMPDIFF()","Difference in units",
"SELECT TIMESTAMPDIFF(DAY,'2026-01-01','2026-02-07') AS result;"],

["date_convert_tz","CONVERT_TZ()","Convert time zone using offsets",
"SELECT CONVERT_TZ(NOW(), '+00:00', '+08:00') AS result;"]

];



$advance_functions = [

["adv_ifnull","IFNULL()","Return second value if first is NULL",
"SELECT IFNULL(NULL,'Fallback') AS result;"],

["adv_nullif","NULLIF()","Return NULL if values are equal",
"SELECT full_name, NULLIF(bonus,100) AS result FROM employees;"],


["adv_coalesce","COALESCE()","First non-NULL value",
"SELECT COALESCE(NULL,NULL,'Hello','World') AS result;"],

["adv_if","IF()","Conditional expression",
"SELECT IF(5>3,'YES','NO') AS result;"],

["adv_case","CASE","Conditional branching using CASE",
"SELECT CASE WHEN 10>20 THEN 'A' WHEN 10=10 THEN 'B' ELSE 'C' END AS result;"],

["adv_cast","CAST()","Convert value to a type",
"SELECT CAST('123' AS UNSIGNED) AS result;"],

["adv_convert","CONVERT()","Convert value to a type/charset",
"SELECT CONVERT('2026-02-07', DATE) AS result;"],

["adv_round2","ROUND()","Round to 2 decimal places",
"SELECT ROUND(123.4567,2) AS result;"],

["adv_format","FORMAT()","Format number with commas",
"SELECT FORMAT(1234567.891,2) AS result;"],

["adv_group_concat","GROUP_CONCAT()","Combine values into one string (example)",
"SELECT GROUP_CONCAT(department SEPARATOR ', ') AS result FROM employees;"],

["adv_distinct","DISTINCT","Unique values (example)",
"SELECT DISTINCT department AS result FROM employees;"],

["adv_count","COUNT()","Count rows",
"SELECT COUNT(*) AS result FROM employees;"],

["adv_sum","SUM()","Sum values",
"SELECT SUM(amount) AS result FROM orders;"],

["adv_avg","AVG()","Average values",
"SELECT AVG(amount) AS result FROM orders;"],

["adv_min","MIN()","Minimum value",
"SELECT MIN(amount) AS result FROM orders;"],

["adv_max","MAX()","Maximum value",
"SELECT MAX(amount) AS result FROM orders;"],

["adv_having","HAVING","Filter grouped results",
"SELECT department, COUNT(*) AS total FROM employees GROUP BY department HAVING COUNT(*) >= 1;"],

["adv_order_by","ORDER BY","Sort results",
"SELECT full_name, department FROM employees ORDER BY department ASC;"],

["adv_limit","LIMIT","Limit number of rows",
"SELECT full_name, department FROM employees LIMIT 5;"],

["adv_like","LIKE","Pattern matching",
"SELECT full_name, email FROM employees WHERE email LIKE '%@%';"],

["adv_in","IN","Match any in a list",
"SELECT full_name, department FROM employees WHERE department IN ('HR','IT');"],

["adv_between","BETWEEN","Range filtering",
"SELECT amount FROM orders WHERE amount BETWEEN 100 AND 1000;"],

["adv_isnull","IS NULL","Check for NULL values",
"SELECT full_name, email FROM employees WHERE email IS NULL;"],

["adv_isnotnull","IS NOT NULL","Check for non-NULL values",
"SELECT full_name, email FROM employees WHERE email IS NOT NULL;"],

["adv_union","UNION","Combine rows from 2 queries",
"SELECT department AS result FROM employees UNION SELECT 'All Departments' AS result;"],

["adv_union_all","UNION ALL","Combine rows including duplicates",
"SELECT department AS result FROM employees UNION ALL SELECT department AS result FROM employees;"],

["adv_subquery","Subquery","Use a query inside a query",
"SELECT full_name, department FROM employees WHERE department = (SELECT department FROM employees LIMIT 1);"],

["adv_exists","EXISTS","Check if subquery returns rows",
"SELECT IF(EXISTS(SELECT 1 FROM employees), 'YES', 'NO') AS result;"],

["adv_join","JOIN","Inner join example (employees + departments lookup derived)",
"SELECT e.full_name, e.department FROM employees e JOIN (SELECT 'HR' AS department UNION SELECT 'IT' UNION SELECT 'Finance' UNION SELECT 'Sales') d ON e.department=d.department LIMIT 10;"],

["adv_view_create","CREATE VIEW (example)","Example statement (won't run in this demo page without multi_query)",
"SELECT 'Tip: CREATE VIEW needs separate execution (not SELECT).' AS result;"]

];
