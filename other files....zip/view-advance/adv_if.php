<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include("../db.php");

$sql = 'SELECT IF(5>3,\'YES\',\'NO\') AS result;';
$result = $conn->query($sql);

if(!$result){
  die("Query error: " . $conn->error . "<br><pre>" . htmlspecialchars($sql) . "</pre>");
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>IF()</title>
<style>
  body{font-family:Arial,sans-serif;padding:14px}
  table{border-collapse:collapse;width:100%;margin-top:12px}
  th,td{border:1px solid #ccc;padding:10px;vertical-align:top}
  th{background:#f4f4f4}
  pre{background:#fafafa;border:1px solid #eee;padding:10px;overflow:auto}
</style>
</head>
<body>

<h2>IF()</h2>
<pre><?= htmlspecialchars($sql) ?></pre>

<?php if($result instanceof mysqli_result): ?>
<table>
<tr>
<?php foreach($result->fetch_fields() as $f): ?>
<th><?= htmlspecialchars($f->name) ?></th>
<?php endforeach; ?>
</tr>

<?php while($row=$result->fetch_assoc()): ?>
<tr>
<?php foreach($row as $val): ?>
<td><?= htmlspecialchars((string)$val) ?></td>
<?php endforeach; ?>
</tr>
<?php endwhile; ?>
</table>
<?php endif; ?>

<p><a href="../index.php">Back</a></p>

</body>
</html>